import { createStore } from 'vuex'
import auth from './auth'
import info from "@/store/info";
import hotels from './hotels';
import booking from './booking.js';

const store = createStore({
    modules: {
        auth,info,hotels,booking
    },

})

export default store