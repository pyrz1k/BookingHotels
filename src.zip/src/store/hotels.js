import fb from "firebase/compat/app";
import "firebase/compat/database";
import "firebase/compat/storage";

class Hotel {
    constructor(id, title, country, city, imageSrc = '', desc, rate, price) {
        this.id = id
        this.title = title
        // this.locate = locate
        this.city = country
        this.country = city
        this.imageSrc = imageSrc
        this.desc = desc
        this.rate = rate
        this.price = price
    }
}

export default {
    state: {},
    mutations: {
        loadHotels(state, payload) {
            state.hotels = payload
        },
        updateHotel(state, {title,  desc, price, rate, id, country, city}) {
            const hotel = state.hotels.find(a => {
                return a.id === id
            })
            hotel.title = title
            hotel.country = country
            hotel.city = city
            hotel.desc = desc
            hotel.rate = rate
            hotel.price = price
        }
    },
    actions: {
        async createHotel({commit}, payload) {
            const image = payload.image
            try {
                const newHotel = new Hotel(
                    payload.id,
                    payload.title,
                    payload.city,
                    payload.country,
                    '',
                    payload.desc,
                    payload.rate,
                    payload.price,


                    payload.key
                )
                const hotel = await fb.database().ref('hotels').push(newHotel)
                const imageExt = image.name.slice(image.name.lastIndexOf('.'))
                const fileData = await fb.storage().ref(`hotels/${hotel.key}.${imageExt}`).put(image)
                const imageSrc = await fb.storage().ref().child(fileData.ref.fullPath).getDownloadURL()
                await fb.database().ref(`hotels/${hotel.key}`).update({imageSrc})
                commit('createHotel', {
                    ...newHotel,
                    imageSrc
                })
            } catch (error) {
                error.message
            }
        },

        // async fetchHotels({commit}) {
        //     const resultHotels = []
        //     try {
        //         const hotelsVal = await fb.database().ref('hotels').once('value')
        //         console.log(hotelsVal)
        //         const hotels = hotelsVal.val()
        //         Object.keys(hotels).forEach(key => {
        //             const hotel = hotels[key]
        //             resultHotels.push(
        //                 new Hotel(
        //                     hotel.id,
        //                     hotel.title,
        //                     // hotel.locate,
        //                     hotel.city,
        //                     hotel.country,
        //                     hotel.imageSrc,
        //                     hotel.desc,
        //                     hotel.rate,
        //                     hotel.price,
        //                     key
        //                 )
        //             )
        //             commit('loadHotels', resultHotels)
        //         })
        //     } catch (error) {
        //         error.message
        //     }
        //     commit('fetchHotels', resultHotels)
        // },

        async search({commit}, {locate}) {
            const resultHotels = []
            try {
                const hotelsVal = await fb.database().ref(`hotels`).once('value')
                const hotels = hotelsVal.val()
                Object.keys(hotels).forEach(key => {
                    const hotel = hotels[key]
                    const country = hotel.country
                    console.log(country)
                    const city = hotel.city
                    console.log(city)
                    if( city === locate || country === locate ){
                        resultHotels.push(
                            new Hotel(
                                hotel.id,
                                hotel.title,
                                hotel.country,
                                hotel.city,
                                hotel.imageSrc,
                                hotel.desc,
                                hotel.rate,
                                hotel.price,
                                key
                            ),

                        )
                        commit('loadHotels', resultHotels)
                        console.log(resultHotels)
                    }
                })
            } catch (error) {
                error.message
            }
        },

        async updateHotel({commit}, {title, desc, price, rate, id, city, country}) {
            const idnt = Number(id)
            console.log(typeof(idnt))
            try {
                const hotels = (await (fb.database().ref(`hotels`).once('value'))).val()
                Object.keys(hotels).forEach(key => {
                    console.log(key);
                    console.log(hotels[key].id);
                    if (idnt === hotels[key].id){
                        fb.database().ref(`hotels/${key}`).update({
                            title,
                            city,
                            country,
                            desc,
                            price,
                            rate
                        })
                        commit('updateHotel', {
                            title,
                            city,
                            country,
                            desc,
                            price,
                            rate,
                        })
                    }
                })
            } catch (error) {
                error.message
            }
        },
        async deleteHotel({commit}, {title, city, country, desc, price, rate, idntf}){
            console.log(idntf)
            const idnt = Number(idntf)
            console.log(typeof(idnt))
            try {
                const hotels = (await (fb.database().ref(`hotels`).once('value'))).val()
                Object.keys(hotels).forEach(key => {
                    console.log(key);
                    console.log(hotels[key].id);
                    if (idnt === hotels[key].id){
                        fb.database().ref(`hotels/${key}`).remove()
                        commit('deleteHotel', {
                            title,
                            city,
                            country,
                            desc,
                            price,
                            rate,
                        })
                    }
                })
            } catch (error) {
                error.message
            }
        },
    },
    getters: {
        hotels(state) {
            return state.hotels
        },
        hotelById(state) {
            return hotelId => {
                return state.hotels.find(hotel => hotel.id === hotelId)
            }
        },
    }
}

