import firebase from "firebase/compat/app";
import "firebase/compat/auth";

export default {
    state: {
        info: {}
    },
    mutations: {
        setInfo(state, info) {
            state.info = info
        },
        clearInfo(state) {
            state.info = {}
        }
    },
    actions: {
        async fetchInformationUser({dispatch, commit}) {
            firebase.auth().onAuthStateChanged(async function(user) {
                if (user != null) {
                    const uid = await dispatch('getUid')
                    const info = (await firebase.database().ref(`/users/${uid}/info`).once('value')).val()
                    commit('setInfo', info)
                }
            });
        },
        async getUid(){
            const user = firebase.auth().currentUser
            return user ? user.uid : null
        }
    },
    getters: {
        info: s => s.info
    }
}