import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/database";

export default {
    actions: {
        async loginUser({dispatch}, {email, password}) {
            await firebase.auth().signInWithEmailAndPassword(email, password)
            await dispatch('getUid')
        },
        async register({dispatch}, {email, password, name}) {
            await firebase.auth().createUserWithEmailAndPassword(email, password)
            const uid = await dispatch('getUid')
            console.log(uid)
            await firebase.database().ref(`/users/${uid}/info`).set({
                name,
                role:'user',
                email
            })

        },
        getUid() {
            const user = firebase.auth().currentUser
            return user ? user.uid : null
        },
        async logout({commit}) {
            await firebase.auth().signOut()
            commit('clearInfo')
        },
    }
}