import fb from "firebase/compat/app";
import "firebase/compat/database";

class Booking {
    constructor(FIO, email_book, phone_book, number_book, dateTo, dateOut, title ){
        this.FIO = FIO
        this.email_book = email_book
        this.phone_book = phone_book
        this.number_book = number_book
        this.dateTo = dateTo
        this.dateOut = dateOut
        this.title = title
        // this.unique = unique
    }
}

export default {
    state:{},
    mutations:{
        loadBooks(state, payload) {
            state.books = payload
        },
    },
    actions:{
        async booking({commit}, payload){
            // console.log(payload)
            try{
                const booksVal = (await fb.database().ref(`booking`).once('value'))
                const books = booksVal.val()
                let count = 0
                Object.keys(books).forEach(key =>{
                    const book = books[key]
                    // console.log(book)
                    const dataTo = book.dateTo
                    const dataOut = book.dateOut

                    let check = true
                    if( (payload.dateTo < dataTo && payload.dateOut < dataTo) ||
                        (payload.dateTo > dataOut && payload.dateOut > dataOut)||
                        book === undefined){
                            console.log(payload.dateTo, payload.dateOut)
                            check = true
                            console.log(check)
                        // this.$router.push('/authresults')
                    } else {
                        count = count + 1
                    }
                })
                if (count == 0){
                    const newBook = new Booking (
                        payload.FIO,
                        payload.email_book,
                        payload.phone_book,
                        payload.number_book,
                        payload.dateTo,
                        payload.dateOut,
                        payload.title,
                        // payload.unique
                    )
                    const books= fb.database().ref(`booking`).push(newBook)
                    console.log(books)
                    commit('booking', {
                        ...newBook
                    })
                }
                else{
                    alert ('Выбрана недоступная дата')
                }
            } catch(error){
                error.message
            }
        },
        async searchBooks({commit}, {email}) {
            const result = []
            try {
                const booksVal = await fb.database().ref(`booking`).once('value')
                const books = booksVal.val()
                Object.keys(books).forEach(key => {
                    const book = books[key] 
                    const mail = book.email_book
                    // console.log(mail)    
                    if( mail === email ) {  
                        result.push(
                            new Booking(
                                book.FIO,
                                book.email_book,
                                book.phone_book,
                                book.number_book,
                                book.dateTo,
                                book.dateOut,
                                book.title,
                                // book.unique,
                                key
                            ),
                        )
                        commit('loadBooks', result)
                    }
                })
            } catch (error) {
                error.message
            }
        },
        async searchBooksAd({commit}) {
            const result = []
            try {
                const booksVal = await fb.database().ref(`booking`).once('value')
                const books = booksVal.val()
                Object.keys(books).forEach(key => {
                    const book = books[key] 
                        result.push(
                            new Booking(
                                book.FIO,
                                book.email_book,
                                book.phone_book,
                                book.number_book,
                                book.dateTo,
                                book.dateOut,
                                book.title,
                                // book.unique,
                                book.key
                            ),
                        )
                        commit('loadBooks', result)
                        console.log(book.key)
                })
            } catch (error) {
                error.message
            }
        },
        async deleteBook( {kl}){
            // console.log(idntf)
            try {
                const bookings = (await (fb.database().ref(`booking`).once('value'))).val()
                Object.keys(bookings).forEach(key => {
                    // console.log(key)
                    if (kl === bookings[key]){
                        fb.database().ref(`booking/${key}`).remove()
                    }
                })
            } catch (error) {
                error.message
            }
        },
    },
    getters:{
        books(state) {
            return state.books
        },
    }
}