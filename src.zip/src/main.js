import { createApp } from 'vue'
import App from './App.vue'
import store from './store'

import { createRouter, createWebHistory } from 'vue-router';


import main from './pages/main-page.vue'
import login from './pages/login-page.vue'
import register from './pages/register-page.vue'
import results from './pages/result-page.vue'
import adminresults from './pages/admin-result.vue'
import authresults from './pages/auth-result-page.vue'
import hotel from './pages/hotel-page.vue'
import authhotel from './pages/auth-hotel-page.vue'
import auth from './pages/Auth.vue'
import editHotel from './pages/editHotel.vue'
import createHotel from './pages/createHotel.vue'
import books from './pages/books.vue'
import booksAd from './pages/booksAd.vue'
import reset from './pages/reset-password.vue'
const app = createApp(App)

import firebase from 'firebase/compat/app';

firebase.initializeApp({
  apiKey: "AIzaSyCH_17w4f3Eo-GjtRPcPeK6bSZp1w_JnTk",
  authDomain: "travel-ccf6e.firebaseapp.com",
  projectId: "travel-ccf6e",
  storageBucket: "travel-ccf6e.appspot.com",
  messagingSenderId: "34736705081",
  appId: "1:34736705081:web:ea2b9b9418c0bc571007e8",
})



const router = createRouter({
    history: createWebHistory(),
    routes:[
        {path: '/', component: main},
        {path: '/login', component: login},
        {path: '/register', component: register},
        {path: '/results', component: results},
        {path: '/authresults', component: authresults},
        {path: '/authhotel/:id', props: true, name:'authhotel', component: authhotel},
        {path: '/hotel/:id', props: true, name:'hotel', component: hotel},
        {path: '/auth', component: auth},
        {path: '/admin-results', component: adminresults},
        {path: '/editHotel/:id', props: true, name:'editHotel', component: editHotel},
        {path: '/createHotel', component: createHotel},
        {path: '/books', props: true, name:'books', component: books},
        {path: '/booksAd', props: true, name:'booksAd', component: booksAd},
        {path: '/reset', component: reset}
    ]
});

app.use(router)
app.use(store)
app.mount('#app')
