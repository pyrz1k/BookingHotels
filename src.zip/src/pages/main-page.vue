<template>
    <TheHeader></TheHeader>
    <Home></Home>
    <BookNow></BookNow>
    <!-- <Packages></Packages> -->
    <Services></Services>
    <Gallery></Gallery>
    <AboutUs></AboutUs>
    <Footer></Footer>
</template>

<script>
import TheHeader from "@/components/TheHeader"
import Home from "@/components/home"
import BookNow from "@/components/BookNow"
// import Packages from "@/components/Packages"
import Services from "@/components/Services"
import Gallery from "@/components/Gallery"
import Footer from "@/components/Footer"
import AboutUs from "@/components/AboutUs"

export default {
  components: {
    TheHeader,
    Home,
    BookNow,
    // Packages,
    Services,
    Gallery,
    Footer,
    AboutUs
  },
}

</script>

<style>

</style>