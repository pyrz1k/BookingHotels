<template>
  <AuthHeader></AuthHeader>

  <div class="edit">
    <!--    <input type="number" placeholder="Введите id" v-model="edittedId">-->
    <input type="text" placeholder="Введите название" v-model="edittedTitle">
    <input type="text" placeholder="Введите страну" v-model="edittedCountry">
    <input type="text" placeholder="Введите город" v-model="edittedCity">

    <input type="text" placeholder="Введите описание" v-model="edittedDesc">
    <input type="number" placeholder="Введите оценку" v-model="edittedRate">
    <input type="number" placeholder="Введите цену" v-model="edittedPrice">
    <input type="submit" class="btn" value="Обновить" @click="onSave()">
  </div>

</template>

<script>
import AuthHeader from "@/components/AuthHeader"

export default {
  props: ['id', 'key'],
  data() {
    return {
      edittedTitle: this.edittedTitle,
      edittedCountry: this.edittedCountry,
      edittedCity: this.edittedCity,
      edittedDesc: this.edittedDesc,
      edittedRate: this.edittedRate,
      edittedPrice: this.edittedPrice,
    }
  },
  components: {
    AuthHeader,
  },
  methods: {
    onSave() {
      if (
          // this.edittedId !== '' &&
          this.edittedTitle !== '' &&
          this.edittedCity !== '' &&
          this.edittedCountry !== '' &&
          this.edittedDesc !== '' &&
          this.edittedRate !== '' &&
          this.edittedPrice !== '') {
        this.$store.dispatch('updateHotel', {
          id: this.id,
          title: this.edittedTitle,
          city: this.edittedCity,
          country: this.edittedCountry,
          desc: this.edittedDesc,
          rate: this.edittedRate,
          price: this.edittedPrice,

        })
      }
    }
  }
}
</script>

<style scoped>
.edit {
  display: flex;
  flex-direction: column;
  width: 50%;
  margin-top: 20rem;
  margin-left: 25%;
  justify-content: center;
  gap: 20px;
}

.edit input {
  border: 2px solid var(--orange);
  height: 5rem;
  text-align: center;

}

.btn {
  display: inline-block;
  background: var(--orange);
  color: #fff;

  border: 0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;

}

.btn:hover {
  background: rgba(255, 165, 0, .2);
  color: var(--orange);
}

</style>