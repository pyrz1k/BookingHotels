<template>

  <div class="login-form-container">
       <img src="/images/close.png" class="form-close" @click="$router.push('/')">

    <form class="form" @submit.prevent="submitHandler">
        <h3>Регистрация</h3>
        <input required id="name" class="box" type="text" placeholder="введите Ваше имя" v-model="name" />
        <input id="email" type="email" class="box" v-model="email" placeholder="введите Ваш email">
        <input id="password" type="password" class="box" v-model="password" placeholder="введите пароль">
  
      <span class="invalid">{{error}}</span>
      <button type="submit" class="btn">Регистрация</button>
   <p>уже есть аккаунт? <a  @click="$router.push('/login')">авторизуйтесь</a></p>
    </form>
  </div>

</template>

<script>
export default {
  data(){
    return{
      name: '',
      email: '',
      password: '',
      error: '',
    }
  },
  methods: {
    async submitHandler() {
      const formData = {
        email: this.email,
        password: this.password,
        name: this.name
      }
      try {
        await this.$store.dispatch('register', formData)
        this.$router.push('/login')
      }catch (e){
        if(this.name.trim() === ''){
          this.error = 'Введите свое имя'
        }else if(e.message === 'Firebase: Password should be at least 6 characters (auth/weak-password).'){
          this.error = 'Введите пароль больше 5 символов'
        }else if(e.message === 'Firebase: The email address is already in use by another account. (auth/email-already-in-use).'){
          this.error = 'Этот e-mail уже используется'
        }else if(e.message === 'Firebase: An internal AuthError has occurred. (auth/internal-error).'){
          this.error = 'Заполните все поля'
        }else if (e.message === 'Firebase: The email address is badly formatted. (auth/invalid-email).'){
          this.error = 'Адрес электронной некорректный или не задан'
        }
      }
    },
  }
}
</script>

<style scoped>

.login-form-container .form-close{
  position: absolute;
  top:2rem; right:3rem;
  width: 5rem;
  color:#fff;
  cursor: pointer;
}


.invalid{
  color:red;
  font-family: sans-serif;
  justify-content: center;
  margin-top: 20px;
}

.btn{
  display: inline-block;
  margin-top: 1rem;
  background:var(--orange);
  color:#fff;
  padding:.8rem 3rem;
  border:0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover{
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
}

.login-form-container{
  position: fixed;
  z-index: 10000;
  min-height: 100vh;
  width:100%;
  background:rgba(0,0,0,.7);
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-form-container.active{
  top:0;
}

.login-form-container form{
  margin:2rem;
  padding:1.5rem 2rem;
  border-radius: .5rem;
  background:#fff;
  width:50rem;
}

.login-form-container form h3{
  font-size: 3rem;
  color:#444;
  text-transform: uppercase;
  text-align: center;
  padding:1rem 0;
}

.login-form-container form .box{
  width:100%;
  padding:1rem;
  font-size: 1.7rem;
  color:#333;
  margin:.6rem 0;
  border:.1rem solid rgba(0,0,0,.3);
  text-transform: none;
}

.login-form-container form .box:focus{
  border-color: var(--orange);;
}

.login-form-container form #remember{
  margin:2rem 0;
}

.login-form-container form label{
  font-size: 1.5rem;
}

.login-form-container form .btn{
  display: block;
  width:100%;
}

.login-form-container form p{
  padding:.5rem 0;
  font-size: 1.5rem;
  color:#666;
}

.login-form-container form p a{
  color:var(--orange);
}

.login-form-container form p a:hover{
  color:#333;
  text-decoration: underline;
}

.login-form-container #form-close{
  position: absolute;
  top:2rem; right:3rem;
  font-size: 5rem;
  color:#fff;
  cursor: pointer;
}
</style>
