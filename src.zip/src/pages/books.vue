<template>
  <AuthHeader></AuthHeader>

  <section class="results">
    <div class="video-container">
      <video src="images/vid-2.mp4" loop autoplay muted></video>
    </div>

    <h1 class="heading">
      V<span>Мои брони</span>
    </h1>

    <div class="hotel" v-for="book in books" :key="book.email_book">
      <p>Название отеля: {{book.title}}</p>
        <p class="name">ФИО: {{ book.FIO }}</p>
        <p class="loc">Дата въезда: {{ book.dateTo}} </p>
        <p>Дата отъезда: {{book.dateOut}} </p>
        <p class="desc">Почта: {{book.email_book}}</p>
        <p class="rate">Телефон: {{ book.phone_book }}</p>
        <p class="price">Количество: {{ book.number_book }}</p>
        <!-- <img src="/images/close.png" class="form-close" @click="deleteBook()"> -->
      </div>
  </section>
</template>

<script>
import AuthHeader from "@/components/AuthHeader"

export default {

  components: {
    AuthHeader,
  },
  methods: {
    // async deleteBook(){
    //   console.log(this.key)
    //    await this.$store.dispatch('deleteBook', {
    //     kl:key
    //   })
    //   this.$router.push('/auth')
    // }
  },
  computed: {
    books() {
      return this.$store.getters.books
    },
   
  },
  mounted() {
    // console.log(this.booking)
    return this.$store.dispatch('searchBooks')
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.results {
  margin-top: 60px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: column;
}

.hotel {
  display: flex;
  flex-direction: row;
  background-color: white;
  opacity: 50%;
  font-size: 2rem;
  padding: 2rem;
  gap: 10rem;
  border-radius: 10px;
  margin-top: 10px;
  width: 80%;
}

.video-container video {
  position: fixed;
  top: 43px;
  left: 0;
  z-index: -1;
  height: 100%;
  width: 100%;
  object-fit: cover;
}

.form-close{
  width: 2%;
}

.btn {
  display: inline-block;
  margin-top: 1rem;
  background: var(--orange);
  color: #fff;
  padding: .8rem 3rem;
  border: 0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover {
  background: rgba(255, 165, 0, .2);
  color: var(--orange);
}

</style>