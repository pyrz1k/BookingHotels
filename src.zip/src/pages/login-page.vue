
<template>

  <div class="login-form-container">
    <img src="/images/close.png" class="form-close" @click="$router.push('/')">
      <!-- <i class="fas fa-times" id="form-close" @click="$router.push('/')"></i> -->

    <form class="form" @submit.prevent="submitHandler">
        <h3>Авторизация</h3>

        <input id="email" type="email" class="box" v-model="email" placeholder="введите Ваш email">


        <input id="password" type="password" class="box" v-model="password" placeholder="введите Ваш пароль">
  
      <span class="invalid">{{error}}</span>
      <button type="submit" class="btn">Авторизация</button>
        <p>еще нет аккаунта? <a  @click="$router.push('/register')">зарегистрируйтесь сейчас</a></p>
        <p>забыли пароль? <a  @click="$router.push('/reset')">Восстановить</a></p>
    </form>
  </div>

</template>

<script>
export default {
  data(){
    return{
      email: '',
      password: '',
      error: '',
    }
  },
  methods: {
    async submitHandler() {
      const formData = {
        email: this.email,
        password: this.password,
      }
      try {
          await this.$store.dispatch('loginUser', formData)
          this.$router.push('/auth')
      }catch (e){
        if(e.message === 'Firebase: An internal AuthError has occurred. (auth/internal-error).'){
          this.error = 'Неправильный пароль'
        }else if (e.message === 'Firebase: There is no user record corresponding to this identifier. The user may have been deleted. (auth/user-not-found).'){
          this.error = 'Пользователя с таким e-mail не существует'
        }else if(e.message === 'Firebase: An internal AuthError has occurred. (auth/internal-error).'){
          this.error = 'Заполните все поля'
        }else if (e.message === 'Firebase: The password is invalid or the user does not have a password. (auth/wrong-password).n'){
          this.error = 'Неправильный пароль'
        }
      }
    },
  }
}
</script>

<style scoped>
.login-form-container .form-close{
  position: absolute;
  top:2rem; right:3rem;
  width: 5rem;
  color:#fff;
  cursor: pointer;
}

.invalid{
  color:red;
  font-family: sans-serif;
  justify-content: center;
  margin-top: 20px;
}

.btn{
  display: inline-block;
  margin-top: 1rem;
  background:var(--orange);
  color:#fff;
  padding:.8rem 3rem;
  border:0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover{
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
}

.login-form-container{
  position: fixed;
  z-index: 10000;
  min-height: 100vh;
  width:100%;
  background:rgba(0,0,0,.7);
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-form-container.active{
  top:0;
}

.login-form-container form{
  margin:2rem;
  padding:1.5rem 2rem;
  border-radius: .5rem;
  background:#fff;
  width:50rem;
}

.login-form-container form h3{
  font-size: 3rem;
  color:#444;
  text-transform: uppercase;
  text-align: center;
  padding:1rem 0;
}

.login-form-container form .box{
  width:100%;
  padding:1rem;
  font-size: 1.7rem;
  color:#333;
  margin:.6rem 0;
  border:.1rem solid rgba(0,0,0,.3);
  text-transform: none;
}

.login-form-container form .box:focus{
  border-color: var(--orange);;
}

.login-form-container form #remember{
  margin:2rem 0;
}

.login-form-container form label{
  font-size: 1.5rem;
}

.login-form-container form .btn{
  display: block;
  width:100%;
}

.login-form-container form p{
  padding:.5rem 0;
  font-size: 1.5rem;
  color:#666;
}

.login-form-container form p a{
  color:var(--orange);
}

.login-form-container form p a:hover{
  color:#333;
  text-decoration: underline;
}

.login-form-container #form-close{
  position: absolute;
  top:2rem; right:3rem;
  font-size: 5rem;
  color:#fff;
  cursor: pointer;
}
</style>
