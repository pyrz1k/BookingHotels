<template>
  <TheHeader></TheHeader>

  <section class="results">
    <div class="video-container">
      <video src="images/vid-2.mp4"  loop autoplay muted></video>
    </div>

    <h1 class="heading">
      <span>Р</span>
      <span>е</span>
      <span>з</span>
      <span>у</span>
      <span>л</span>
      <span>ь</span>
      <span>т</span>
      <span>а</span>
      <span>т</span>
      <span class="space"></span>
      <span>п</span>
      <span>о</span>
      <span>и</span>
      <span>с</span>
      <span>к</span>
      <span>а</span>
    </h1>

    <div class="hotel">

      <div class="firstcol">
        <img src="test1.jpg" alt="альтернативный текст">
      </div>

      <div class="secondcol">
        <p class="name">Lorem ipsum dolor.</p>
        <p class="loc">Lorem ipsum dolor sit amet,</p>
        <p class="desc">Lorem ipsum dolor sit amet, consectetur 123 23 123 adipisicing elit. Eius, sequi.</p>
      </div>


      <div class="thirdcol">
        <p class="rate">rate</p>
        <p class="price">price</p>
        <div class="button">
          <input type="submit" class="btn" value="Редактировать" @click="$router.push('/editHotel')">

          <input type="submit" class="btn" value="Забронировать" @click="$router.push('/hotel')">
        </div>


      </div>

    </div>




  </section>

</template>

<script>

import TheHeader from "@/components/TheHeader"
export default {
  components: {
    TheHeader,

  },
}
</script>

<style scoped>
*{
  box-sizing: border-box;
}

.results{
  margin-top: 60px;
  display: flex;
  justify-content:space-between ;
  align-items: center;
  flex-direction: column;
}

.hotel{
  display: flex;
  gap: 30px;
  justify-content:space-evenly ;
  align-items: center;
  border: 1px solid black;
  border-radius: 10px;
  width: 50%;
  height: 300px;
  margin-bottom: 35px;
  margin-top: -20px;
  background-color: rgba(255, 255, 255, 0.7);
}

/* .firstcol{

} */

.firstcol img{
  border-radius: 10px;
  margin-left: 30px;
  width: 400px;
  height: 250px;
}

.secondcol{
  width: 300px;
  border-left: 1px solid black;
  padding-left: 10px;
  height: 100%;
}

.thirdcol{
  display: flex;
  flex-direction: column;
  margin-right: 10px;
  padding-left: 10px;
  border-left: 1px solid black;
  height: 100%;

}


.name{
  font-size: 2rem;
  color:black;
}

.loc{
  font-size: 2rem;
  color:black;
}

.desc{
  margin-top: 50px;
  font-size: 2rem;
  color:black;
}

.rate {
  padding-bottom: 120px;
  margin-bottom: 50px;
  font-size: 2rem;
  color:black;
}

.price{
  font-size: 2rem;

}

.book{
  margin-bottom: 20px;
  font-size: 2rem;
  color:black;
}

.video-container video{
  position: fixed;
  top:43px; left: 0;
  z-index: -1;
  height: 100%;
  width:100%;
  object-fit: cover;
}

.btn{
  display: inline-block;
  background:var(--orange);
  color:#fff;
  padding:.8rem 3rem;
  border:0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover{
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
}

</style>
