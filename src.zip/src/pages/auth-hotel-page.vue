<template>
  <AuthHeader></AuthHeader>
  <div class="color">
    <div class="video-container">
      <video src="/images/vid-5.mp4" loop autoplay muted></video>
    </div>

    <section class="full">
      <div class="hotelPage">
        <div class="hotel">
          <p class="title">{{ title }}</p>
              <p class="loc">{{ city }}, {{ country }}</p>
            <div class="firstcol">
            <div class="nl">
              
            </div>
            <img :src="imageSrc" alt="альтернативный текст">
            <p class="description">{{ desc }}</p>
          </div>
          
        <div class="scbtn">
            <div class="secondcol">
              <p class="rating">Оценка:{{ rate }}</p>
              <p class="price">Цена:{{ price }}руб.</p>
            </div>
            <div class="buttons" v-if="role === 'admin'">
                  <button class="btn btn2" @click="this.$router.push({
                            name:'editHotel',
                            params:{
                                id
                                }
                                }
                            )">Редактировать
                  </button>
                  <button class="btn btn2" @click="deleteHotel({params:{
                                id
                                }})">Удалить
                  </button>
            </div>
        </div>
        </div>
      </div>


      <div class="book">
        <form @submit.prevent="submitHandler">

          <div class="date">
            <div class="dateTo">
              <label for="date">Выберите дату заезда:</label>
              <input class="date" type="date" name="date" required v-model="dateTo">
            </div>

            <div class="dateOut">
              <label for="date">Выберите дату отъезда:</label>
              <input class="date" type="date" name="date" required v-model="dateOut">
            </div>
          </div>
          <div class="submits">
            <input type="text" placeholder="ФИО" required v-model="FIO">
            <input type="email" placeholder="email" required v-model="email_book">
            <input type="tel" placeholder="Телефон" required v-model="phone_book">
            <input type="number" placeholder="Кол-во гостей" required v-model="number_book">
            <!-- <input type="number" placeholder="Введите уникальное число" required unique v-model="unique"> -->
          </div>
          <input type="submit" class="btn" value="Забронировать">
        </form>

      </div>
    </section>

  </div>


</template>

<script>

import AuthHeader from "@/components/AuthHeader"

export default {
  data() {
    return {
      FIO: "",
      email_book: "",
      phone_book: "",
      number_book: "",
      dateOut: "",
      dateTo: "",
      unique: "",
    }
  },
  components: {
    AuthHeader
  },
  props: ['id', 'title', 'country', 'city', 'price', 'desc', 'rate', 'imageSrc'],
     computed: {
    role() {
      return this.$store.getters.info.role
    },
    hotel() {
      const key = this.id
      return this.$store.getters.hotelById(key)

    },
  },
  mounted(){
    console.log()
    this.$store.dispatch('fetchInformationUser')
      },
  methods: {
    async logout() {
      await this.$store.dispatch('logout')
      this.$router.push('/')
    },
    async submitHandler() {
      const book = {

        FIO: this.FIO,
        email_book: this.email_book,
        phone_book: this.phone_book,
        number_book: this.number_book,
        dateTo: this.dateTo,
        dateOut: this.dateOut,
        title: this.title,
        // unique: this.unique,

      }
      await this.$store.dispatch('booking', book)
      console.log(book)
      // this.$router.push('/auth')
    },
    async deleteHotel() {
      const idnt = this.id
      const idntf = Number(idnt)
      
      await this.$store.dispatch('deleteHotel', {
        idntf:idntf
      })
      this.$router.push('/auth')
    }
  },

}
</script>

<style scoped>

.container .logo span {
  color: var(--orange);
}


.navbar a {
  color: #fff;
  font-size: 2rem;
  margin: 0.8rem;
}

.container .navbar a:hover {
  color: var(--orange);
  font-size: 2.9rem;
}

.container .navbar a {
  color: #fff;
  font-size: 2rem;
  margin: 0 .8rem;
}

.container .navbar a:hover {
  color: var(--orange);
}

img {
  width: 4rem;
  color: #fff;
  cursor: pointer;
  margin-right: 2rem;
  height: 35rem;
}

img:hover {
  color: var(--orange);
   
}


* {
  box-sizing: border-box;
}


label {
  font-size: 2rem;
  font-family: 'Nunito', sans-serif;
}

.submits input {
  border: 2px solid var(--orange);
  height: 5rem;
  text-align: center;
  align-content: center;
  width: 100%;

}

.submits{
    padding: 2rem
}

* {
  color: black;
}

.video-container video {
  position: fixed;
  top: 43px;
  left: 0;
  z-index: -1;
  height: 100%;
  width: 100%;
  object-fit: cover;
}


.full {
  display: inline-block;
  margin: auto;
  border: 5px solid var(--orange);
  width: 45%;
  height: auto;
  background-color: rgba(255, 255, 255, 0.8);
  transform: translate(60%);
  margin-top: 10rem;
  border-radius: 2rem
}

.hotel {
  display: flex;
  flex-direction: column;
  height: 100%;

}

.firstcol{
display:flex;
flex-direction: row;
margin-left: -3rem;
gap:0
}

.firstcol img {
  width: 65%;
  margin-left: 45px;
  margin-top: 10px;
  border-radius: 3rem;
}

.firstcol img:hover {
  transform: scale(1.2, 1.2);
}

.title {
  font-family: 'Nunito', sans-serif;
  font-size: 4rem;
}

.loc {
  font-family: 'Nunito', sans-serif;
  font-size: 3rem;
  color: black;
}

.description {
  font-family: 'Nunito', sans-serif;
  font-size: 2rem;
}

form {
  display: flex;
  flex-direction: column;
  gap: 15px;

}

.book {
  margin-left: 20px;
  font-size: 1.5rem;
  font-family: 'Nunito', sans-serif;
}


.submits {
  display: flex;
  gap: 15px;
}

.date {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.dateTo {
  display: flex;
  gap: 26px;
}

.dateOut {
  display: flex;
  gap: 15px;
}

.date input {
  border: 2px solid var(--orange);
}


.btn {
  display: inline-block;
  background: var(--orange);
  color: #fff;
  padding: .8rem 3rem;
  border: 0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
  margin-left: -20px;
  margin-top: 3px;
}

.btn2 {
  width: 20rem;
  align-content: center;
}

.buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.btn:hover {
  background: rgba(255, 165, 0, .2);
  color: var(--orange);
}

.secondcol {
  font-size: 3.5rem;
  font-family: 'Nunito', sans-serif;
}

.title,
.loc,
.rating,
.price{
  margin-left: 20px;
}

.scbtn{
  display: flex;
  flex-direction: row;
  gap: 35rem;
}
</style>
