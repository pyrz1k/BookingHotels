<template>

  <AuthHeader></AuthHeader>

    <AuthHome></AuthHome>
    <AuthBookNow></AuthBookNow>
    <!-- <Packages></Packages> -->
    <Services></Services>
    <Gallery></Gallery>
    <AboutUs></AboutUs>
    <Footer></Footer>

</template>

<script>
import AuthHome from "@/components/auth-home"
import AuthBookNow from "@/components/AuthBookNow"
import AuthHeader from "@/components/AuthHeader"
// import Packages from "@/components/Packages"
import Services from "@/components/Services"
import Gallery from "@/components/Gallery"
import Footer from "@/components/Footer"
import AboutUs from "@/components/AboutUs"

export default {
     components: {
    AuthHome,
    AuthHeader,
    AuthBookNow,
    // Packages,
    Services,
    Gallery,
    Footer,
    AboutUs
  },
  methods:{
    async logout() {
      await this.$store.dispatch('logout')
      this.$router.push('/')
    }
  },
  computed: {
    name() {
      return this.$store.getters.info.name
    }
  },
  mounted() {
    this.$store.dispatch('fetchInformationUser')
  }
}
</script>

<style scoped>



</style>