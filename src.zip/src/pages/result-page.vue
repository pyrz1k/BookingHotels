<template>
  <TheHeader></TheHeader>

  <section class="results">
    <div class="video-container">
      <video src="images/vid-2.mp4" loop autoplay muted></video>
    </div>

    <h1 class="heading">
      <span>Р</span>
      <span>е</span>
      <span>з</span>
      <span>у</span>
      <span>л</span>
      <span>ь</span>
      <span>т</span>
      <span>а</span>
      <span>т</span>
      <span class="space"></span>
      <span>п</span>
      <span>о</span>
      <span>и</span>
      <span>с</span>
      <span>к</span>
      <span>а</span>
    </h1>

    <div class="hotel" v-for="hotel in hotels" :key="hotel.id">

      <div class="firstcol">
        <img :src="hotel.imageSrc" alt="альтернативный текст">
      </div>

      <div class="secondcol">
        <p class="name">{{ hotel.title }}</p>
        <p class="loc">{{hotel.city}}, {{hotel.country}}</p>
        <p class="desc">{{hotel.desc}}</p>
      </div>

      <div class="thirdcol">
        <p class="rate">Оценка:{{ hotel.rate }}</p>
        <p class="price">Цена:{{ hotel.price }}руб.</p>


        <input type="submit" class="btn" value="Просмотр" @click="this.$router.push({
                    name:'hotel',
                    params:{
                        id:hotel.id,
                        title:hotel.title,
                        country:hotel.country,
                        city:hotel.city,
                        imageSrc:hotel.imageSrc,
                        desc:hotel.desc,
                        price:hotel.price,
                        rate:hotel.rate,
                        key:this.key
                        }
                        }
                        )">
      </div>
    </div>
  </section>
</template>

<script>
import TheHeader from "@/components/TheHeader"

export default {
  props: ['id', 'title', 'locate', 'price', 'desc', 'rate', 'key'],
  components: {
    TheHeader,
  },
  computed: {
    hotels() {
      return this.$store.getters.hotels

    },
  },
  mounted() {
    return this.$store.dispatch('search')
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.results {
  margin-top: 60px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: column;
}

.hotel {
  display: flex;
  gap: 30px;
  justify-content: space-evenly;
  align-items: center;
  border: 1px solid black;
  border-radius: 10px;
  width: 50%;
  height: auto;
  margin-bottom: 35px;
  margin-top: -20px;
  background-color: rgba(255, 255, 255, 0.7);
}

.firstcol img {
  border-radius: 10px;
  margin-left: 30px;
  width: 400px;
  height: 250px;
}

.secondcol {
  width: 300px;
  border-left: 1px solid black;
  padding-left: 10px;
  height: 100%;
}

.thirdcol {
  margin-right: 10px;
  padding-left: 10px;
  border-left: 1px solid black;
  height: 100%;
}


.name {
  font-size: 2rem;
  color: black;
}

.loc {
  font-size: 2rem;
  color: black;
}

.desc {
  font-size: 2rem;
  color: black;
  padding: 2rem;
}

.rate {
  padding-bottom: 120px;
  margin-bottom: 50px;
  font-size: 2rem;
  color: black;
}

.price {
  font-size: 2rem;
}

.book {
  margin-bottom: 20px;
  font-size: 2rem;
  color: black;
}

.video-container video {
  position: fixed;
  top: 43px;
  left: 0;
  z-index: -1;
  height: 100%;
  width: 100%;
  object-fit: cover;
}

.btn {
  display: inline-block;
  margin-top: 1rem;
  background: var(--orange);
  color: #fff;
  padding: .8rem 3rem;
  border: 0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover {
  background: rgba(255, 165, 0, .2);
  color: var(--orange);
}

</style>