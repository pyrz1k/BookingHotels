<template>
  <AuthHeader></AuthHeader>
  <div class="video-container">
    <video src="images/vid-3.mp4" loop autoplay muted></video>
  </div>
  <div class="create">
    <form class="form" @submit.prevent="submitHandler">
      <div class="title">Добавление отеля</div>
      <div class="about">
        <h3>Введите id отеля:</h3>
        <input id="id" class="input" type="number" placeholder=" " v-model="id"/>
      </div>
      <div class="about">
        <h3>Введите название отеля:</h3>
        <input id="title" class="input" type="text" placeholder=" " v-model="title"/>
      </div>

<!--      <div class="about">-->
<!--        <h3>Введите местоположение отеля:</h3>-->
<!--        <input id="locate" class="input" type="text" placeholder=" " v-model="locate"/>-->
<!--      </div>-->

      <div class="about">
        <h3>Введите страну:</h3>
        <input id="country" class="input" type="text" placeholder=" " v-model="country"/>
      </div>


      <div class="about">
        <h3>Введите город:</h3>
        <input id="city" class="input" type="text" placeholder=" " v-model="city"/>
      </div>
      <div class="about">
        <h3>Выберите фото отеля:</h3>
        <input
            ref="fileInput"
            id="imageSrc"
            class="input"
            type="file"
            placeholder=" "
            accept="image/*"
            @change="onFileChange">
      </div>


      <div class="about">
        <h3>Введите описание отеля:</h3>
        <input id="desc" class="input" type="text" placeholder=" " v-model="desc"/>
      </div>

      <div class="about">
        <h3>Введите оценку отеля:</h3>
        <input id="rate" class="input" type="float" placeholder=" " v-model="rate"/>
      </div>

      <div class="about">
        <h3>Введите стоимость за ночь:</h3>
        <input id="price" class="input" type="number" placeholder=" " v-model="price"/>
      </div>


      <button type="submit" class="submit">Добавить отель</button>
    </form>
  </div>

</template>

<script>
import AuthHeader from "@/components/AuthHeader"

export default {
  components: {
    AuthHeader,
  },
  data() {
    return {
      id: '',
      title: '',
      // locate: '',
      country: '',
      city: '',
      image: null,
      imageSrc: '',
      desc: '',
      rate: '',
      price: ''
    }
  },
  methods: {
    async submitHandler() {
      const hotel = {
        id: this.id,
        title: this.title,
        // locate: this.locate,
        country: this.country,
        city: this.city,
        image: this.image,
        desc: this.desc,
        rate: this.rate,
        price: this.price,
      }
      await this.$store.dispatch('createHotel', hotel)
      // this.$router.push('/authresults')
    },
    onFileChange(event) {
      const file = event.target.files[0]
      const reader = new FileReader()
      reader.onload = (event) => {
        this.imageSrc = event.result
      }
      // console.log(this.imageSrc)
      reader.readAsDataURL(file)
      this.image = file
    }
  }
}
</script>

<style scoped>
.video-container video {
  position: fixed;
  top: 0;
  left: 0;
  z-index: -1;
  height: 100%;
  width: 100%;
  object-fit: cover;
}

.create {
  display: flex;
  flex-direction: column;
  margin-top: 20rem;
  margin-left: 32%;
  color: #fff;
}

.input {
  border: 2px solid var(--orange);
  height: 5rem;
  text-align: center;
  width: 100%;
  opacity: 50%;
  font-size: 2rem;
  color: black;
}

#imageSrc {
  opacity: 80%;
}

.about {
  margin-bottom: 2rem;;
}

.form {
  width: 50%
}

.submit {
  display: inline-block;
  background: var(--orange);
  color: #fff;
  width: 100%;
  border: 0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
  height: 5rem;
}

.submit:hover {
  background: rgba(255, 165, 0, .2);
  color: var(--orange);
}

.title {
  font-size: 5rem;
  width: 100%;
}

h3 {
  font-size: 2rem;
}

</style>