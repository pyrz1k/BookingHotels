<template>
<section class="services" id="services">

    <h1 class="heading">
        <span>С</span>
        <span>е</span>
        <span>р</span>
        <span>в</span>
        <span>и</span>
        <span>c</span>
        <span>ы</span>
    </h1>

    <div class="box-container">
        <div class="upper">
            <div class="box">
                <i class="fas fa-hotel"></i>
                <h3>Доступные отели</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore commodi earum, quis voluptate exercitationem ut minima itaque iusto ipsum corrupti!</p>
            </div>
            <div class="box">
                <i class="fas fa-utensils"></i>
                <h3>Еда и напитки</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore commodi earum, quis voluptate exercitationem ut minima itaque iusto ipsum corrupti!</p>
            </div>
            <div class="box">
                 <i class="fas fa-globe-asia"></i>
                 <h3>Вокруг мира</h3>
                 <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore commodi earum, quis voluptate exercitationem ut minima itaque iusto ipsum corrupti!</p>
            </div>
        </div>
       
       <div class="down">
            <div class="box">
                <i class="fas fa-plane"></i>
                <h3>Быстрое путешествие</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore commodi earum, quis voluptate exercitationem ut minima itaque iusto ipsum corrupti!</p>
            </div>
            <div class="box">
                <i class="fas fa-hiking"></i>
                <h3>Приключения</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Inventore commodi earum, quis voluptate exercitationem ut minima itaque iusto ipsum corrupti!</p>
            </div>
       </div>
        

    </div>

</section>
</template>

<script>
export default {
  name: 'Services',
}
</script>

<style scoped>



.services .box-container .upper{
  display: grid;
  grid-template-columns: 300px 300px 300px;
  gap:1.5rem;
  justify-content: center;
}

.services .box-container .down{
  display: grid;
  grid-template-columns: 300px 300px ;
  gap:1.5rem;
  justify-content: center;
}

.services .box-container .box{
  border-radius: 0.5rem;
  padding:1rem;
  text-align: center;
}

.services .box-container .box i{
  padding:1rem;
  font-size: 5rem;
  color:var(--orange);
}

.services .box-container .box h3{
  font-size: 2.5rem;
  color:#333;
}

.services .box-container .box p{
  font-size: 1.5rem;
  color:#666;
  padding:1rem 0;
}

.services .box-container .box:hover{
  box-shadow: 0 1rem 2rem rgba(0,0,0,.1);
}


</style>