<template>

  <section class="home" id="home">

    <div class="content">
      <h3>ПРИКЛЮЧЕНИЕ ТОГО СТОИТ</h3>
      <p>Открывайте новые места вместе с нами, Вас ждут приключения</p>
    </div>
    <div class="video-container">
      <video src="images/vid-1.mp4"  loop autoplay muted></video>
    </div>
    <div v-if="role === 'admin'">
      <input type="submit" class="btn" value="Добавить отель" @click="createHotel" >
    </div>
    
  </section>


</template>

<script>
export default {
  name: "auth-home",

  methods:{
    createHotel(){
      this.$router.push('/createHotel')
    }
  },
  computed: {
    role() {
      return this.$store.getters.info.role
    }
  },
  mounted(){
    this.$store.dispatch('fetchInformationUser')
  }
}
</script>

<style scoped>

#home{
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: column;
  position: relative;
  z-index: 0;
}

.home .content{
  text-align: center;
}

.home .content h3{
  font-size: 4.5rem;
  color:#fff;
  text-transform: uppercase;
  text-shadow: 0 .3rem .5rem rgba(0,0,0,.1);
}

.home .content p{
  font-size: 2.5rem;
  color:#fff;
  padding:.5rem 0;
}

.home .video-container video{
  position: absolute;
  top:0; left: 0;
  z-index: -1;
  height: 100%;
  width:100%;
  object-fit: cover;
}


.btn{
  display: inline-block;
  margin-top: 1rem;
  background:var(--orange);
  color:#fff;
  padding:.8rem 3rem;
  border:0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover{
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
}
</style>