<template>
<section class="contacts" id="review">

    <div class="container">

      <h1 class="heading">
       <span>О</span>
       <span class="space"></span>
        <span>Н</span>
        <span>а</span>
        <span>с</span>
    </h1>

      <div class="contacts-content">
        <ul class="cantacts__list">
          <li class="cantacts__item">
            <strong class="cantacts__title">Адрес</strong>
            <p class="cantacts__address">
              Lorem ipsum dolor sit amet.
            </p>
          </li>
          <li class="cantacts__item">
            <strong class="cantacts__title">Телефон:</strong>
            <a href="123123" class="cantacts__number">123123123</a>
          </li>
          <li class="cantacts__item">
            <strong class="cantacts__title">Эл.Адрес:</strong>
            <p class="cantacts__address">
              <a href="123132123@mail.ru">13123123@mail.ru</a> 
            </p>
          </li>
          <li class="cantacts__item">
            <strong class="cantacts__title">Время работы</strong>
            <p class="cantacts__address">
              Понедельник - пятница, с 10:00 до 19:00
            </p>
          </li>
        </ul>
      </div>
      
    </div>
  </section>
</template>


<script>
export default {
  name: 'contacts',
}
</script>


<style scoped>
.contacts {
    display: flex;
    justify-content: center;
    text-align: center;
    font-size: 2.5rem;
    

}

li{
list-style-type: none;
}




</style>