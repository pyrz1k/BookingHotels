<template>

<section class="home" id="home">

    <div class="content">
        <h3>ПРИКЛЮЧЕНИЕ ТОГО СТОИТ</h3>
        <p>Открывайте новые места вместе с нами, Вас ждут приключения</p>
    </div>
    <div class="video-container">
        <video src="images/vid-1.mp4"  loop autoplay muted></video>
    </div>

</section>

</template>

<script>
export default {
  name: 'Home',
}
</script>

<style scoped>

#home{
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: column;
  position: relative;
  z-index: 0;
}

.home .content{
  text-align: center;
}

.home .content h3{
  font-size: 4.5rem;
  color:#fff;
  text-transform: uppercase;
  text-shadow: 0 .3rem .5rem rgba(0,0,0,.1);
}

.home .content p{
  font-size: 2.5rem;
  color:#fff;
  padding:.5rem 0;
}

.home .video-container video{
  position: absolute;
  top:0; left: 0;
  z-index: -1;
  height: 100%;
  width:100%;
  object-fit: cover;
}

.home .controls{
  padding:1rem;
  border-radius: 5rem;
  background:rgba(0,0,0,.7);
  position: relative;
  top:10rem;
}

.home .controls .vid-btn{
  height:2rem;
  width:2rem;
  display: inline-block;
  border-radius: 50%;
  background:#fff;
  cursor: pointer;
  margin:0 .5rem;
}

.home .controls .vid-btn.active{
  background:var(--orange);
}

</style>