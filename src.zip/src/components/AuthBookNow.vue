<template>

<section class="book" id="book">

    <h1 class="heading">
        <span>З</span>
        <span>а</span>
        <span>б</span>
        <span>р</span>
        <span>о</span>
        <span>н</span>
        <span>и</span>
        <span>р</span>
        <span>у</span>
        <span>й</span>
        <span>т</span>
        <span>е</span>
        <span class="space"></span>
        <span>у</span>
        <span>ж</span>
        <span>е</span>
        <span class="space"></span>
        <span>с</span>
        <span>е</span>
        <span>й</span>
        
        <span>ч</span>
        <span>а</span>
        <span>с</span>
    </h1>

    <div class="row">

        <div class="image">
            <img src="images/book-img.svg" alt="">
        </div>

         <form @submit.prevent="search">
            <div class="inputBox">
                <h3>Куда?</h3>
                <input type="text" v-model="location" placeholder="Введите название локации" required>
            </div>
            <input type="submit" class="btn" value="Искать" @click="search()" >
        </form>

    </div>

</section>

</template>

<script>
export default {
  name: 'AuthBookNow',
  data(){
    return{
      location:this.location
    }
  },
  methods:{
       async search(){
        const location = this.location
        const locate = location
        // console.log(this.location)
        if(locate != null) {
          await this.$store.dispatch('search', {
          locate
          })
        this.$router.push('/authresults')
        }
        
      }
        // console.log(this.location)
      }
    
}
</script>

<style scoped>

section {
    padding: 2rem 9%;
}

.book .row{
  display: flex;
  gap:1.5rem;
  align-items: center;
}

.book .row .image{
  flex:1 1 20rem;
}

.book .row .image img{
  width:100%;
}

.book .row form{
  flex: 40rem;
  padding:2rem;
  box-shadow: 0 1rem 2rem rgba(0,0,0,.1);
  border-radius: .5rem;
}

.book .row form .inputBox{
  padding:.5rem 0;
}

.book .row form .inputBox input{
  width:100%;
  padding:1rem;
  border:.1rem solid rgba(0,0,0,.1);
  font-size: 1.7rem;
  color:#333;
  text-transform: none;
}

.book .row form .inputBox h3{
  font-size: 2rem;
  padding:1rem 0;
  color:#666;
}

.heading{
  text-align: center;
  padding:2.5rem 0
}

.heading span{
  font-size: 3.5rem;
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
  border-radius: .5rem;
  padding:0.2rem 1rem;
}

.btn{
  display: inline-block;
  margin-top: 1rem;
  background:var(--orange);
  color:#fff;
  padding:.8rem 3rem;
  border:0.2rem solid var(--orange);
  cursor: pointer;
  font-size: 1.7rem;
}

.btn:hover{
  background:rgba(255, 165, 0,.2);
  color:var(--orange);
}

</style>