<template>

<section class="footer">

    <div class="box-container">
      
        <div class="box">
            <h3>Расположение филиалов</h3>
            <a href="#">Россия</a>
            <a href="#">Казахстан</a>
            <a href="#">Белоруссия</a>
            <a href="#">Украина</a>
        </div>
        <div class="box">
            <h3>Быстрая навигация</h3>
            <a href="#home">Домашняя</a>
            <a href="#book">Жилье</a>
            <a href="#gallery">Галерея</a>
            <a href="#review">О нас</a>
            <a href="#contact">Контакты</a>
        </div>
        <div class="box">
            <h3>Подписывайтесь</h3>
            <a href="#">facebook</a>
            <a href="#">instagram</a>
            <a href="#">VK</a>
        </div>

    </div>

    <!-- <h1 class="credit"> created by <span> mr. web designer </span> | all rights reserved! </h1> -->

</section>

</template>


<script>
export default {
  name: 'Footer',
}
</script>


<style scoped>
.footer{
  background:#333;
}

.footer .box-container{
  display: grid;
  grid-template-columns: 300px 300px 300px;
  gap:12rem;
  justify-content:center;
  margin-left: 25rem;
}

.footer .box-container .box{
  padding:1rem 0;
  flex:1 1 25rem;
}

.footer .box-container .box h3{
  font-size: 2.5rem;
  padding:.7rem 0;
  color:#fff;
}

.footer .box-container .box p{
  font-size: 1.5rem;
  padding:.7rem 0;
  color:#eee;
}

.footer .box-container .box a{
  display: block;
  font-size: 1.5rem;
  padding:.7rem 0;
  color:#eee;
}

.footer .box-container .box a:hover{
  color:var(--orange);
  text-decoration: underline;
}

.footer .credit{
  text-align: center;
  padding:2rem 1rem;
  margin-top: 1rem;
  font-size: 2rem;
  font-weight: normal;
  color:#fff;
  border-top: .1rem solid rgba(255,255,255,.2);
}

.footer .credit span{
  color:var(--orange);
}
</style>