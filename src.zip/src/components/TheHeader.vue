<template>

<div class="container">
    <a href="#" class="logo" @click="$router.push('/')"><span>T</span>ravel</a>

    <nav class="navbar">
        <a href="#home">Домашняя</a>
        <a href="#book">Жилье</a>
        <a href="#gallery">Галерея</a>
        <a href="#review">О нас</a>
    </nav>

    <div class="icons">
      <img class="icon" src="/images/user.png"  @click="$router.push('/login')">
    </div>
    <!-- <form action="" class="SearchBar">
            <input type="search" id="search-bar" placeholder="Поиск...">
            <label for="search-bar" class="fas fa-search"></label>
    </form> -->
</div>

</template>

<script>
export default {
  name: 'TheHeader',
}
</script>

<style scoped>

.container{
  position: fixed;
  top:0; left: 0; right:0;
  background:#333;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding:2rem 9%;
  height: 8rem;
}

.container .logo{
  font-size: 2rem;
  color:#fff;
  text-transform: uppercase;
}

.container .logo span{
  color:var(--orange);
}

.navbar{
    display:grid;
    grid-template-columns: 200px 200px 200px 200px;
    grid-template-rows: 50px;
    justify-content: center;
    text-align: center;
    margin-top: 15px
}

.navbar a{
  color:#fff;
  font-size: 2rem;
  margin: 0.8rem;
}

.container .navbar a:hover{
  color:var(--orange);
  font-size: 2.9rem;
}
.container .navbar a{
  color:#fff;
  font-size: 2rem;
  margin:0 .8rem;
}

.container .navbar a:hover{
  color:var(--orange);
}

img{

  width: 4rem;
  color:#fff;
  cursor: pointer;
  margin-right: 2rem;
}

img:hover{
  color:var(--orange);
}


.SearchBar{
  position: absolute;
  top:100%; left: 0; right:0;
  padding:1.5rem 0.2rem;
  /* background:#333; */
  border: 3px solid #333;
  border-radius: 10px;
  display: flex;
  align-items: center;
  width: 12%;
  height: 5%;
}


.SearchBar #search-bar{
  width:100%;
  padding:1rem;
  text-transform: none;
  color:#333;
  font-size: 1.7rem;
  border-radius: 0.5rem;
  height: 5%;
}

.SearchBar label{
  color:gray;
  cursor: pointer;
  font-size: 2rem;
  margin-left: 1.5rem;
}

.SearchBar label:hover{
  color:var(--orange);
}

</style>